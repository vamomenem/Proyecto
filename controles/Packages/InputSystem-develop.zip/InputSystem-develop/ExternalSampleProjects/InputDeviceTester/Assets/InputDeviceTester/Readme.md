Q: What is this?
A: This is a additional test to the New Input System.
   It includes keyboard, mouse, xbox controller, pen and newly added touch.
   It also comes with a generic diagram for other gamepads.

Q: Who made this?
   This is made by @jia.
   Please email me any comment/concern or poke me in Slack directly.

Q: How to use this?
   When using New Input System, use Ctrl+[num] to switch input method test, and Ctrl+I to see More Information.
     Ctrl + 1: Keyboard and mouse
     Ctrl + 2: Xbox controller
     Ctrl + 3: General controller diagram
     Ctrl + 4: Pen
     Ctrl + 5: Touch
     Ctrl + I: More Information
   When using Old Input Manager, use the Dropdown UI element to switch.
   When using both, either/or would work.
   *The setting can be changed at: Player Settings -> Other Settings -> Active Input Handling

Q: Why are there so many scripts for Old Input Manager?
   Because the goal is to test both old and new input together at the same time.

Q: There are so much going on at the same time! I don't know what I'm looking at...
A: Generally speaking, anything BLUE is for the Old Input Manager, and anything RED are for the New Input System.
   For example: if a message shows up in blue font, it is related to the Old Input Manager.
