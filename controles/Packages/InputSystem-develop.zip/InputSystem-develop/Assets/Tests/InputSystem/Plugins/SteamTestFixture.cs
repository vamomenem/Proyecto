namespace UnityEngine.InputSystem.Steam
{
    public class SteamTestFixture
    {
    }
}
