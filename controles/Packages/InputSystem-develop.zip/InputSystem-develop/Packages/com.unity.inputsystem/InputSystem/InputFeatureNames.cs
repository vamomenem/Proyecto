namespace UnityEngine.InputSystem
{
    internal static class InputFeatureNames
    {
        public const string kFeatureRunPlayerUpdatesInEditMode = "RUN_PLAYER_UPDATES_IN_EDIT_MODE";
    }
}
